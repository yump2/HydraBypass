#include "LicenseManager.h"
#include <QUrl>
#include <QUrlQuery>
#include <QNetworkRequest>

LicenseManager::LicenseManager(QObject *parent) : QObject(parent) {
    networkManager = new QNetworkAccessManager(this);
    connect(networkManager, &QNetworkAccessManager::finished, this, &LicenseManager::onValidationReply);
}

void LicenseManager::validateKey(const QString &email, const QString &key) {
    QUrl url("https://your-license-api.com/validate");
    QUrlQuery postData;
    postData.addQueryItem("email", email);
    postData.addQueryItem("key", key);

    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/x-www-form-urlencoded");

    networkManager->post(request, postData.query().toUtf8());
}

void LicenseManager::onValidationReply(QNetworkReply *reply) {
    if (reply->error() == QNetworkReply::NoError) {
        QByteArray response = reply->readAll();
        QJsonDocument json = QJsonDocument::fromJson(response);
        if (json["valid"].toBool()) {
            emit licenseValidated(true, "License Validated");
        } else {
            emit licenseValidated(false, "Invalid License");
        }
    } else {
        emit licenseValidated(false, "Network Error");
    }
    reply->deleteLater();
}
