#ifndef LICENSEMANAGER_H
#define LICENSEMANAGER_H

#include <QString>
#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QJsonDocument>

class LicenseManager : public QObject {
    Q_OBJECT

public:
    explicit LicenseManager(QObject *parent = nullptr);
    void validateKey(const QString &email, const QString &key);

signals:
    void licenseValidated(bool success, const QString &message);

private slots:
    void onValidationReply(QNetworkReply *reply);

private:
    QNetworkAccessManager *networkManager;
};

#endif // LICENSEMANAGER_H
